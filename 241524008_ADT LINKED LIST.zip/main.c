#include "adt.h"

int main() {
    // Data mahasiswa
    Mahasiswa dataMahasiswa[] = {
        {"Jacob Green", 81}, {"Abigail Adams", 94}, {"James Anderson", 87},
        {"Emily Johnson", 92}, {"Lucas Carter", 83}, {"Lily Mitchell", 88},
        {"Henry Perez", 82}, {"Ella Roberts", 88}, {"Jack Evans", 89},
        {"Scarlett Collins", 91}, {"Noah Stewart", 78}, {"Grace Sanchez", 86},
        {"Samuel Baker", 87}, {"Chloe Rivera", 92}, {"David Phillips", 79},
        {"Victoria Campbell", 80}, {"James Anderson", 87}, {"Emily Johnson", 92},
        {"Mason Parker", 84}, {"Aria Edwards", 93}, {"Logan Hughes", 81},
        {"Zoey Bennett", 88}
    };

    // Menghitung jumlah elemen dalam array
    int jumlahMahasiswa = sizeof(dataMahasiswa) / sizeof(dataMahasiswa[0]);

    // Deklarasi list
    List L1, L2;

    // Inisialisasi list
    initList(&L1);
    initList(&L2);

    // Memasukkan data ke dalam List L1 secara terurut
    for (int i = 0; i < jumlahMahasiswa; i++) {
        insertSorted(&L1, dataMahasiswa[i]);
    }

    // Menampilkan List L1 (Ascending berdasarkan Nama)
    printf("\n=== List L1 (Ascending Nama) ===\n");
    displayList(L1);

    // Menyalin elemen dengan nilai UTS > 70 ke L2
    copyIfGreater(L1, &L2, 70);

    // Menampilkan List L2 sebelum menghapus duplikat
    printf("\n=== List L2 sebelum Menghapus Duplikat ===\n");
    displayList(L2);

    // Menghapus duplikat nama dari L2
    removeDuplicates(&L2);

    // Menampilkan List L2 setelah menghapus duplikat
    printf("\n=== List L2 setelah Menghapus Duplikat ===\n");
    displayList(L2);

    // Menghapus semua list
    deleteList(&L1);
    deleteList(&L2);

    return 0;
}

