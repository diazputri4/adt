#ifndef ADT_H
#define ADT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char nama[50];
    int nilaiUTS;
} Mahasiswa;

typedef struct Node {
    Mahasiswa data;
    struct Node* next;
} Node;

typedef Node* List;

// Fungsi ADT
void initList(List* head);
Node* createNode(Mahasiswa mhs);
void insertSorted(List* head, Mahasiswa mhs);
void displayList(List head);
void copyIfGreater(List L1, List* L2, int threshold);
void removeDuplicates(List* head);
void deleteList(List* head);

#endif

