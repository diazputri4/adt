#include "adt.h"

// Inisialisasi list kosong
void initList(List* head) {
    *head = NULL;
}

// Membuat node baru
Node* createNode(Mahasiswa mhs) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (!newNode) return NULL;
    newNode->data = mhs;
    newNode->next = NULL;
    return newNode;
}

// Menyisipkan elemen ke dalam list secara ascending berdasarkan nama
void insertSorted(List* head, Mahasiswa mhs) {
    Node* newNode = createNode(mhs);
    if (!newNode) return;

    // Jika list kosong atau data lebih kecil dari head
    if (*head == NULL || strcmp(mhs.nama, (*head)->data.nama) < 0) {
        newNode->next = *head;
        *head = newNode;
        return;
    }

    Node* current = *head;
    while (current->next != NULL && strcmp(current->next->data.nama, mhs.nama) < 0) {
        current = current->next;
    }

    newNode->next = current->next;
    current->next = newNode;
}

// Menampilkan isi list
void displayList(List head) {
    while (head) {
        printf("Nama: %s, Nilai UTS: %d\n", head->data.nama, head->data.nilaiUTS);
        head = head->next;
    }
}

// Menyalin elemen dengan nilai UTS lebih dari threshold ke L2
void copyIfGreater(List L1, List* L2, int threshold) {
    while (L1) {
        if (L1->data.nilaiUTS > threshold) {
            insertSorted(L2, L1->data);
        }
        L1 = L1->next;
    }
}

// Menghapus duplikat nama dalam L2
void removeDuplicates(List* head) {
    Node *current = *head, *prev, *temp;
    
    while (current != NULL) {
        prev = current;
        Node *checker = current->next;

        while (checker != NULL) {
            if (strcmp(current->data.nama, checker->data.nama) == 0) {
                temp = checker;
                prev->next = checker->next;
                free(temp);
                checker = prev->next;
            } else {
                prev = checker;
                checker = checker->next;
            }
        }
        current = current->next;
    }
}

// Menghapus seluruh list
void deleteList(List* head) {
    Node* current = *head;
    Node* next;

    while (current) {
        next = current->next;
        free(current);
        current = next;
    }

    *head = NULL;
}

